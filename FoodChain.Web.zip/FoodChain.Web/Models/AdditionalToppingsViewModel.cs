﻿using FoodChain.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FoodChain.Models
{
    public class AdditionalToppingsViewModel
    {
        public IEnumerable<Topping> Toppings { get; set; }
    }
}