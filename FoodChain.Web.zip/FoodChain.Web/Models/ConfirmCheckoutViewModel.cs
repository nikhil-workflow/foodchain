﻿using FoodChain.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FoodChain.Models
{
    public class ConfirmCheckoutViewModel
    {
        public UserProfile User { get; set; }
        public ICollection<Product> Products { get; set; }
        public Order Order { get; set; }
        public ICollection<Topping> Toppings { get; set; }
    }
}