﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FoodChain.Domain.Entities;
using System.ComponentModel.DataAnnotations;

namespace FoodChain.Models
{
    public class ProductListViewModel
    {
        [Key]
        public IEnumerable<Product> Products { get; set; }
        public string CurrentStatus { get; set; }
    }
}