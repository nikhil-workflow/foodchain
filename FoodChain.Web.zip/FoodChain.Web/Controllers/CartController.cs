﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodChain.Domain.Abstract;
using FoodChain.Domain.Entities;
using FoodChain.Models;
using WebMatrix.WebData;
using System.Text.RegularExpressions;
using FoodChain.Common;

namespace FoodChain.Controllers
{
    public class CartController : Controller
    {
        private IProductRepository repository;
        private IOrderlineRepository orderlineRepository;
        private IOrderRepository orderRepository;
        private IDeliveryRepository deliveryRepository;
        private IVoucherRepository voucherRepository;
        private IProductToppingOrderRepository ProductToppingOrderRepository;

        public CartController(IProductRepository repo, IOrderlineRepository orderlineRepo, IOrderRepository orderRepo, IDeliveryRepository deliveryRepo, IVoucherRepository voucherRepo, IProductToppingOrderRepository ProductToppingOrderRepo)
        {
            repository = repo;
            orderlineRepository = orderlineRepo;
            orderRepository = orderRepo;
            deliveryRepository = deliveryRepo;
            voucherRepository = voucherRepo;
            ProductToppingOrderRepository = ProductToppingOrderRepo;
        }

        public ViewResult Index(Cart cart, string returnUrl)
        {
            return View(new CartIndexViewModel
            {
                Cart = cart,
                ReturnUrl = returnUrl,
            });
        }

        public RedirectToRouteResult AddToCart(Cart cart, int ProductId, string returnUrl)
        {
            Product Product = repository.Products.FirstOrDefault(p => p.ProductId == ProductId);

            if (Product != null)
            {
                if (Product.Name == Constants.CreateOwned)
                {
                    foreach (var topping in Session[SessionKeys.ToppingList] as List<Topping>)
                    {
                        Product.Price += topping.Price;
                    }
                    cart.AddItem(Product, 1);
                }
                else
                {
                    cart.AddItem(Product, 1);
                }
                
            }
            return RedirectToAction(ActionName.Index, new { returnUrl });
        }

        public RedirectToRouteResult RemoveFromCart(Cart cart, int ProductId, string returnUrl)
        {
            Product Product = repository.Products.FirstOrDefault(p => p.ProductId == ProductId);

            if (Product != null)
            {
                cart.RemoveLine(Product);
            }
            return RedirectToAction(ActionName.Index, new { returnUrl });
        }


        public PartialViewResult Summary(Cart cart)
        {
            return PartialView(cart);
        }

        [Authorize]
        public ViewResult Checkout(Cart cart)
        {
            var context = new UsersContext();
            var username = User.Identity.Name;
            var user = context.UserProfiles.SingleOrDefault(u => u.UserName == username);

            return View(new CartCheckoutViewModel
            {
                User = user,
                Cart = cart,
                DeliveryTypes = deliveryRepository.Deliveries.ToList(),
                Voucher = null
            });
            
            //return View(user);
        }

       

        [Authorize]
        public ViewResult ConfirmCheckout(Cart cart, int deliveryId)
        {
            Delivery delivery = deliveryRepository.Deliveries.FirstOrDefault(d => d.DeliveryId == deliveryId);
            Order order = new Order();
            order.PriceBeforeVouchers = cart.GetTotalValue();
            order.UserId = WebSecurity.CurrentUserId;
            order.TimeSubmitted = DateTime.Now;
            
            order.DeliveryId = deliveryId;
            order.Subtotal = order.PriceBeforeVouchers + delivery.Cost;
            order.Total = order.Subtotal;
            order.Status =Constants.Processed;
            orderRepository.SaveOrder(order);
            int orderId = orderRepository.Orders.FirstOrDefault(o => o.TimeSubmitted == order.TimeSubmitted).OrderId;
            List<Product> Products = new List<Product>();

            foreach(var cartLine in cart.Lines){
                for(int i=0;i<cartLine.Quantity;i++)
                {
                    Orderline orderline = new Orderline();
                    orderline.ProductId = cartLine.Product.ProductId;
                    orderline.OrderlinePrice = cartLine.Product.Price * cartLine.Quantity;
                    orderline.UserId = WebSecurity.CurrentUserId;
                    orderline.OrderId = order.OrderId;
                    orderlineRepository.SaveOrderline(orderline);
                    Products.Add(repository.Products.FirstOrDefault(p => p.ProductId == orderline.ProductId));
                    Product Product = repository.Products.FirstOrDefault(p => p.ProductId == orderline.ProductId);
                    if (Product.Name == Constants.CreateOwned)
                    {
                        foreach (var topping in Session[SessionKeys.ToppingList] as List<Topping>)
                        {
                            ProductToppingOrder ProductToppingOrder = new ProductToppingOrder();
                            ProductToppingOrder.OrderlineId = orderline.OrderlineId;
                            ProductToppingOrder.ToppingId = topping.ToppingId;
                            ProductToppingOrderRepository.SaveProductToppingOrder(ProductToppingOrder);
                        }
                    }
                }
            }

            cart.Clear();
            ViewBag.PriceBeforeVouchers = order.PriceBeforeVouchers;
            
            ViewBag.DeliveryCost = delivery.Cost;
            ViewBag.PriceIncDelivery = order.PriceBeforeVouchers + delivery.Cost;
            ViewBag.DeliveryType = delivery.DeliveryType;
            
            var context = new UsersContext();
            var username = User.Identity.Name;
            var user = context.UserProfiles.SingleOrDefault(u => u.UserName == username);

            List<Topping> toppings = Session[SessionKeys.ToppingList] as List<Topping>;

            return View(new ConfirmCheckoutViewModel
            {
                User = user,
                Order = order,
                Products =  Products,
                Toppings = toppings
            });            
        }

        

        [Authorize]
        public ActionResult SaveCurrentOrder(Cart cart)
        {
            var orderlineQuery = orderlineRepository.Orderlines.Where(u => u.UserId == WebSecurity.CurrentUserId).ToList();
            foreach (var orderline in orderlineQuery)
            {
                if (orderline != null)
                {
                    orderlineRepository.ClearOrderline(orderline);
                }
            }

            for(int i = 0; i<cart.Lines.Count(); i++){
                
                var line = cart.Lines.ElementAt(i);
                for (int j = 0; j < line.Quantity; j++)
                {
                    Orderline orderline = new Orderline();
                    orderline.ProductId = line.Product.ProductId;
                    orderline.OrderlinePrice = line.Product.Price;
                    orderline.UserId = WebSecurity.CurrentUserId;
                    orderlineRepository.SaveOrderline(orderline);
                }
                
            }
            TempData["message"] = string.Format("Order saved");

            return RedirectToAction(ActionName.Index);
        }

        public ActionResult SubmitVoucher(string voucherCode = "0")
        {

                    
             if (Request.IsAjaxRequest())
             {
                 //Voucher voucher;
                 //if (voucherCode != "")
                 //{
                     Voucher voucher = voucherRepository.Vouchers.FirstOrDefault(v => v.Code == voucherCode);
                 //}
                 //else
                // {
                 //    voucher = new Voucher();
                 //}
                  return PartialView(ActionName.VoucherArea, voucher);
             }
             else
             {
                  return View();
             }
        }

        [Authorize]
        public ActionResult RetrieveSavedOrder(Cart cart)
        {
            var orderlineQuery = orderlineRepository.Orderlines.Where(u => u.UserId == WebSecurity.CurrentUserId).ToList();
            cart.Clear();
            foreach (var orderline in orderlineQuery)
            {
                if (orderline != null)
                {
                    if (orderline.OrderId == 0)
                    {
                        Product Product = new Product();
                        Product.ProductId = orderline.ProductId;
                        Product.Name = repository.Products.FirstOrDefault(p => p.ProductId == Product.ProductId).Name;
                        Product.Size = repository.Products.FirstOrDefault(p => p.ProductId == Product.ProductId).Size;
                        Product.Price = orderline.OrderlinePrice;
                        cart.AddItem(Product, 1);
                        TempData["message"] = string.Format("Order Retrieved");
                    }
                }
            }

            if(orderlineQuery.Count() == 0){
                TempData["message"] = string.Format("No Items Saved");               
            }
            return RedirectToAction(ActionName.Index);
        }

        public String VoucherCheck(string VoucherCode)
        {
            string voucherCode = Regex.Replace(VoucherCode, @"<[^>]*>", String.Empty);

            String voucherResponse = "Voucher '" + voucherCode + "' is not a valid code.";
            if (voucherCode == "PD201401061" || voucherCode == "PD201401062" || voucherCode == "PD201401063" || voucherCode == "PD201401064" || voucherCode == "PD201401065" || voucherCode == "PD201401066")
            {
                 voucherResponse = "Voucher " + voucherCode + " is a valid code. GREAT DEAL!";
            }
            return voucherResponse;
        }

    }        
}
