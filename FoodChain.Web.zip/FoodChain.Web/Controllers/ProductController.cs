﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodChain.Domain.Abstract;
using FoodChain.Models;
using FoodChain.Domain.Entities;
using System.Data.Entity;
using FoodChain.Common;

namespace FoodChain.Controllers
{
    public class ProductController : Controller
    {
        private IProductRepository repository;
        private IToppingRepository toppingRepository;
        private List<Topping> toppingList = new List<Topping>();

        public ProductController(IProductRepository ProductRepository, IToppingRepository toppingRepo)
        {
            repository = ProductRepository;
            toppingRepository = toppingRepo;
        }

        public ViewResult List()
        {
            ProductListViewModel viewModel = new ProductListViewModel
            {
                Products = repository.Products
                    .Where(p => p.Status == Constants.Available)
            };


            return View(viewModel);
        }

        public ViewResult ViewProduct(Product Product)
        {
            Product ProductDetails;
            var Products = repository.Products.Include(Constants.RObjects.ProductToppings);
            ProductDetails = Products.FirstOrDefault(p => p.ProductId == Product.ProductId);
            var allToppings = toppingRepository.Toppings.Where(t => t.Size == Product.Size).ToList();

            ProductSelectViewModel viewModel = new ProductSelectViewModel
            {
                Product = ProductDetails,
                Toppings = allToppings
            };

            toppingList = new List<Topping>();
            Session[SessionKeys.ToppingList] = new List<Topping>();
            return View(viewModel);
        }

        public PartialViewResult AddCustomTopping(int toppingId)
        {
            Topping topping = toppingRepository.Toppings.FirstOrDefault(t => t.ToppingId == toppingId);
            List<Topping> toppingsTemp = new List<Topping>();
            toppingsTemp.Add(topping);
            
            foreach (Topping eachTopping in Session[SessionKeys.ToppingList] as List<Topping>)
            {
                toppingList.Add(eachTopping);
            }
            toppingList.Add(topping);
            Session[SessionKeys.ToppingList] = toppingList;

            decimal toppingsPrice = 0;
            foreach(var toppingPrice in toppingList){
                toppingsPrice += toppingPrice.Price;
            }
            CustomToppingViewModel viewModel = new CustomToppingViewModel
            {
                Toppings = toppingList,
                ToppingsPrice = toppingsPrice
            };
            
            return PartialView(viewModel);
        }
       
    }
}
