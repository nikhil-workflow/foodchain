﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodChain.Domain.Abstract;
using FoodChain.Domain.Concrete;
using Ninject;
using Ninject.Syntax;

namespace FoodChain.Infrastructure
{
    public class NinjectDependencyResolver : IDependencyResolver 
    {
        private IKernel kernel;

        public NinjectDependencyResolver()
        {
            kernel = new StandardKernel();
            AddBindings();
        }

        public object GetService(Type serviceType)
        {
            return kernel.TryGet(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return kernel.GetAll(serviceType);
        }

        public IBindingToSyntax<T> Bind<T>()
        {
            return kernel.Bind<T>();
        }

        public IKernel Kernel
        {
            get { return kernel; }
        }

        private void AddBindings(){

            Bind<IProductRepository>().To<EFProductRepository>();
            Bind<IOrderlineRepository>().To<EFOrderlineRepository>();
            Bind<IOrderRepository>().To<EFOrderRepository>();
            Bind<IDeliveryRepository>().To<EFDeliveryRepository>();
            Bind<IVoucherRepository>().To<EFVoucherRepository>();
            Bind<IToppingRepository>().To<EFToppingRepository>();
            Bind<IProductToppingOrderRepository>().To<EFProductToppingOrderRepository>();
        }
    }
}