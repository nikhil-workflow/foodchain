﻿using System;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FoodChain.Domain.Entities;
using FoodChain.Domain.Concrete;
using FoodChain.Domain.Abstract;
using Moq;
using System.Linq;
using FoodChain.Controllers;
using FoodChain.Models;
using System.Collections.Generic;
using System.Web.Mvc;


namespace FoodChain.Test.Controller
{
    [TestClass]
    public class CartControllerTest
    {

        [TestMethod]
        public void IndexActionLoads()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            CartController controller = new CartController(mock.Object, null, null, null, null, null);
            Cart cart = new Cart();

            //Action
            ViewResult result = controller.Index(cart, null) as ViewResult;

            //Assert
            Assert.AreEqual(result.ViewName, "");
        }

        [TestMethod]
        public void CanAddToCart()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            mock.Setup(p => p.Products).Returns(new Product[]{
                new Product {ProductId = 1, Name = "Product1"},
            }.AsQueryable());

            Cart cart = new Cart();
            CartController controller = new CartController(mock.Object, null, null, null, null, null);

            //Action
            controller.AddToCart(cart, 1, null);

            //Assert
            Assert.AreEqual(cart.Lines.Count(), 1);
        }

        [TestMethod]
        public void AddToCartGoesToShoppingList()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            mock.Setup(p => p.Products).Returns(new Product[]{
                new Product {ProductId = 1, Name = "Product1"},
            }.AsQueryable());

            Cart cart = new Cart();
            CartController controller = new CartController(mock.Object, null, null, null, null, null);

            //Action
            RedirectToRouteResult result = controller.AddToCart(cart, 1, "testUrl");

            //Assert
            Assert.AreEqual(result.RouteValues["action"], "Index");
            Assert.AreEqual(result.RouteValues["returnUrl"], "testUrl");
        }

        [TestMethod]
        public void CanViewCart()
        {
            //Arrange
            Cart cart = new Cart();
            Delivery delivery = new Delivery();
            CartController controller = new CartController(null, null, null, null, null, null);

            //Action
            CartIndexViewModel result = (CartIndexViewModel)controller.Index(cart, "testUrl").ViewData.Model;

            //Assert
            Assert.AreSame(result.Cart, cart);
            Assert.AreEqual(result.ReturnUrl, "testUrl");
        }

        [TestMethod]
        public void CanEnterValidVoucher()
        {
            //Arrange
            Cart cart = new Cart();
            CartController controller = new CartController(null, null, null, null, null, null);

            //Action
            String voucherResponse = controller.VoucherCheck("PD201401062");

            //Assert
            Assert.AreEqual("Voucher PD201401062 is a valid code. GREAT DEAL!", voucherResponse);
        }

        [TestMethod]
        public void CanEnterInvalidVoucher()
        {
            //Arrange
            Cart cart = new Cart();
            CartController controller = new CartController(null, null, null, null, null, null);

            //Action
            String voucherResponse = controller.VoucherCheck("PD1401062");

            //Assert
            Assert.AreEqual("Voucher 'PD1401062' is not a valid code.", voucherResponse);
        }

    }
}
