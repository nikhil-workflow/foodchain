﻿using System;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FoodChain.Domain.Entities;
using FoodChain.Domain.Concrete;
using FoodChain.Domain.Abstract;
using Moq;
using System.Linq;
using FoodChain.Controllers;
using FoodChain.Models;
using System.Collections.Generic;
using System.Web.Mvc;


namespace FoodChain.Test.Controller
{
    [TestClass]
    public class ProductControllerTest
    {
        [TestMethod]
        public void ListActionLoads()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            ProductController controller = new ProductController(mock.Object, null);

            //Action
            ViewResult result = controller.List() as ViewResult;

            //Assert
            Assert.AreEqual(result.ViewName, "");
        }

        [TestMethod]
        public void CanCreateMenu()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            mock.Setup(m => m.Products).Returns(new Product[]{
                new Product { ProductId = 1, Name = "Product1", Status = "Available"},
                new Product { ProductId = 2, Name = "Product2", Status = "Available"}
            }.AsQueryable());

            ProductController controller = new ProductController(mock.Object, null);

            //Action
            Product[] results = ((ProductListViewModel)controller.List().Model).Products.ToArray();

            //Assert
            Assert.AreEqual(results.Length, 2);
        }

        [TestMethod]
        public void CanFilterProductByStatus()
        {
            //Arrange
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            mock.Setup(m => m.Products).Returns(new Product[]{
                new Product { ProductId = 1, Name = "Product1", Status = "Available"},
                new Product { ProductId = 2, Name = "Product2", Status = "NotAvailable"}
            }.AsQueryable());

            ProductController controller = new ProductController(mock.Object, null);

            //Action
            Product[] result = ((ProductListViewModel)controller.List().Model).Products.ToArray();

            //Assert
            Assert.AreEqual(result.Length, 1);
            Assert.IsTrue(result[0].Name == "Product1" && result[0].Status == "Available");
        }
    }
}
