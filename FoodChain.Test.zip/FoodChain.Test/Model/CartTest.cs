﻿using System;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FoodChain.Domain.Entities;
using FoodChain.Domain.Concrete;
using FoodChain.Domain.Abstract;
using Moq;
using System.Linq;
using FoodChain.Controllers;
using FoodChain.Models;
using System.Collections.Generic;
using System.Web.Mvc;


namespace FoodChain.Test.Model
{
    [TestClass]
    public class CartTest
    {
        [TestMethod]
        public void CanAddANewLine()
        {
            //Arrange
            Product p1 = new Product { ProductId = 1, Name = "Product1" };
            Product p2 = new Product { ProductId = 2, Name = "Product2" };
            Cart cart = new Cart();

            //Action
            cart.AddItem(p1, 1);
            cart.AddItem(p2, 1);
            CartLine[] results = cart.Lines.ToArray();

            //Assert
            Assert.AreEqual(results.Length, 2);
            Assert.AreEqual(results[1].Product, p2);
        }

        [TestMethod]
        public void CanAddQuantityToExistingLine()
        {
            //Arrange
            Product p1 = new Product { ProductId = 1, Name = "Product1" };
            Product p2 = new Product { ProductId = 2, Name = "Product2" };
            Cart cart = new Cart();

            //Action
            cart.AddItem(p1, 1);
            cart.AddItem(p2, 1);
            cart.AddItem(p1, 5);
            CartLine[] results = cart.Lines.OrderBy(p => p.Product.ProductId).ToArray();

            //Assert
            Assert.AreEqual(results.Length, 2);
            Assert.AreEqual(results[0].Quantity, 6);
            Assert.AreEqual(results[1].Quantity, 1);
        }

        [TestMethod]
        public void CanRemoveLine()
        {
            //Arrange
            Product p1 = new Product { ProductId = 1, Name = "Product1" };
            Product p2 = new Product { ProductId = 2, Name = "Product2" };
            Product p3 = new Product { ProductId = 3, Name = "Product3" };
            Cart cart = new Cart();

            //Action
            cart.AddItem(p1, 1);
            cart.AddItem(p2, 2);
            cart.AddItem(p1, 5);
            cart.AddItem(p3, 3);
            cart.RemoveLine(p1);

            //Assert
            Assert.AreEqual(cart.Lines.Count(), 2);
            Assert.AreEqual(cart.Lines.Where(p => p.Product == p1).Count(), 0);
        }

        [TestMethod]
        public void CalcCartTotal()
        {
            //Arrange
            Product p1 = new Product { ProductId = 1, Name = "Product1", Price = 5M };
            Product p2 = new Product { ProductId = 2, Name = "Product2", Price = 3.50M };
            Product p3 = new Product { ProductId = 3, Name = "Product3", Price = 51M };
            Cart cart = new Cart();

            //Action
            cart.AddItem(p1, 1);
            cart.AddItem(p2, 2);
            cart.AddItem(p3, 1);
            decimal result = cart.GetTotalValue();

            //Assert
            Assert.AreEqual(result, 63M);
        }

        [TestMethod]
        public void CanClearCart()
        {
            //Arrange
            Product p1 = new Product { ProductId = 1, Name = "Product1", Price = 5M };
            Product p2 = new Product { ProductId = 2, Name = "Product2", Price = 3.50M };
            Product p3 = new Product { ProductId = 3, Name = "Product3", Price = 51M };
            Cart cart = new Cart();

            //Action
            cart.AddItem(p1, 1);
            cart.AddItem(p2, 2);
            cart.AddItem(p3, 1);
            cart.Clear();

            //Assert
            Assert.AreEqual(cart.Lines.Count(), 0);
        }
    }
}
